#include "Bullet.h"
#include "../../Utility/InputControl.h"
#include "DxLib.h"